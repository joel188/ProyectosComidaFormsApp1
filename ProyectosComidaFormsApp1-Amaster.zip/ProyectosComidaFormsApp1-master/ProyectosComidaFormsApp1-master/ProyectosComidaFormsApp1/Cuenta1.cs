﻿namespace ProyectosComidaFormsApp1
{
    public class CuentaS
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public decimal Saldo { get; set; }
    }
}
