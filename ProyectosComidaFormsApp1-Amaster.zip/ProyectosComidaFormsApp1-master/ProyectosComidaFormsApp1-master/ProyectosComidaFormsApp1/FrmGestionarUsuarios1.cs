﻿using System;

namespace ProyectosComidaFormsApp1
{
    internal class FrmGestionarUsuarios
    {
        public FrmCuenta MdiParent { get; internal set; }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}