﻿using System;
namespace ProyectosComidaFormsApp1
{
    partial class FrmCuenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NombClientxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboCalificacion = new System.Windows.Forms.ComboBox();
            this.comboMenu = new System.Windows.Forms.ComboBox();
            this.Ubicaciontxt = new System.Windows.Forms.TextBox();
            this.NumClientxt = new System.Windows.Forms.TextBox();
            this.NumEmptxt = new System.Windows.Forms.TextBox();
            this.nomEmptxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pedidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoPedidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // NombClientxt
            // 
            this.NombClientxt.Location = new System.Drawing.Point(360, 127);
            this.NombClientxt.Name = "NombClientxt";
            this.NombClientxt.Size = new System.Drawing.Size(250, 22);
            this.NombClientxt.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(157, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "Nombre de cliente";
            // 
            // comboCalificacion
            // 
            this.comboCalificacion.FormattingEnabled = true;
            this.comboCalificacion.Items.AddRange(new object[] {
            "1. Estrella",
            "2. Estrellas",
            "3. Estrellas",
            "4. Estrellas",
            "5. Estrellas"});
            this.comboCalificacion.Location = new System.Drawing.Point(360, 297);
            this.comboCalificacion.Name = "comboCalificacion";
            this.comboCalificacion.Size = new System.Drawing.Size(250, 24);
            this.comboCalificacion.TabIndex = 27;
            // 
            // comboMenu
            // 
            this.comboMenu.FormattingEnabled = true;
            this.comboMenu.Items.AddRange(new object[] {
            "Filete Miñon",
            "Langosta",
            "Hamburguesa",
            "Sopa de hongos de Miso",
            "Pescado Frito"});
            this.comboMenu.Location = new System.Drawing.Point(360, 211);
            this.comboMenu.Name = "comboMenu";
            this.comboMenu.Size = new System.Drawing.Size(250, 24);
            this.comboMenu.TabIndex = 26;
            // 
            // Ubicaciontxt
            // 
            this.Ubicaciontxt.Location = new System.Drawing.Point(360, 255);
            this.Ubicaciontxt.Name = "Ubicaciontxt";
            this.Ubicaciontxt.Size = new System.Drawing.Size(250, 22);
            this.Ubicaciontxt.TabIndex = 25;
            // 
            // NumClientxt
            // 
            this.NumClientxt.Location = new System.Drawing.Point(360, 169);
            this.NumClientxt.Name = "NumClientxt";
            this.NumClientxt.Size = new System.Drawing.Size(250, 22);
            this.NumClientxt.TabIndex = 24;
            // 
            // NumEmptxt
            // 
            this.NumEmptxt.Location = new System.Drawing.Point(360, 85);
            this.NumEmptxt.Name = "NumEmptxt";
            this.NumEmptxt.Size = new System.Drawing.Size(250, 22);
            this.NumEmptxt.TabIndex = 23;
            // 
            // nomEmptxt
            // 
            this.nomEmptxt.Location = new System.Drawing.Point(360, 43);
            this.nomEmptxt.Name = "nomEmptxt";
            this.nomEmptxt.Size = new System.Drawing.Size(250, 22);
            this.nomEmptxt.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(158, 302);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 16);
            this.label7.TabIndex = 21;
            this.label7.Text = "Calificacion";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(156, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "Ubicacion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(156, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 16);
            this.label5.TabIndex = 19;
            this.label5.Text = "Nombre del empleado";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(158, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Menu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(158, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Numero de cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(157, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Numero del empleado";
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.Location = new System.Drawing.Point(670, 385);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(82, 31);
            this.btnConfirmar.TabIndex = 30;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = true;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(554, 385);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(93, 30);
            this.btnCancelar.TabIndex = 31;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.pedidosToolStripMenuItem,
            this.usuarioToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 30);
            this.menuStrip1.TabIndex = 32;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salirToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(73, 26);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(121, 26);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // pedidosToolStripMenuItem
            // 
            this.pedidosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoPedidosToolStripMenuItem});
            this.pedidosToolStripMenuItem.Name = "pedidosToolStripMenuItem";
            this.pedidosToolStripMenuItem.Size = new System.Drawing.Size(75, 26);
            this.pedidosToolStripMenuItem.Text = "Pedidos";
            // 
            // nuevoPedidosToolStripMenuItem
            // 
            this.nuevoPedidosToolStripMenuItem.Name = "nuevoPedidosToolStripMenuItem";
            this.nuevoPedidosToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.nuevoPedidosToolStripMenuItem.Text = "Nuevo Pedidos";
            this.nuevoPedidosToolStripMenuItem.Click += new System.EventHandler(this.NuevoPedidosToolStripMenuItem_Click);
            // 
            // usuarioToolStripMenuItem
            // 
            this.usuarioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionarUsuarioToolStripMenuItem});
            this.usuarioToolStripMenuItem.Name = "usuarioToolStripMenuItem";
            this.usuarioToolStripMenuItem.Size = new System.Drawing.Size(73, 26);
            this.usuarioToolStripMenuItem.Text = "Usuario";
            // 
            // gestionarUsuarioToolStripMenuItem
            // 
            this.gestionarUsuarioToolStripMenuItem.Name = "gestionarUsuarioToolStripMenuItem";
            this.gestionarUsuarioToolStripMenuItem.Size = new System.Drawing.Size(209, 26);
            this.gestionarUsuarioToolStripMenuItem.Text = "Gestionar Usuario";
            this.gestionarUsuarioToolStripMenuItem.Click += new System.EventHandler(this.GestionarUsuarioToolStripMenuItem_Click);
            // 
            // FrmCuenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnConfirmar);
            this.Controls.Add(this.NombClientxt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboCalificacion);
            this.Controls.Add(this.comboMenu);
            this.Controls.Add(this.Ubicaciontxt);
            this.Controls.Add(this.NumClientxt);
            this.Controls.Add(this.NumEmptxt);
            this.Controls.Add(this.nomEmptxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmCuenta";
            this.Text = "FrmCuenta";
            this.Load += new System.EventHandler(this.FrmCuenta_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox NombClientxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboCalificacion;
        private System.Windows.Forms.ComboBox comboMenu;
        private System.Windows.Forms.TextBox Ubicaciontxt;
        private System.Windows.Forms.TextBox NumClientxt;
        private System.Windows.Forms.TextBox NumEmptxt;
        private System.Windows.Forms.TextBox nomEmptxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pedidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuevoPedidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarUsuarioToolStripMenuItem;
        private EventHandler btnConfirmar_Click;
        private EventHandler btnCancelar_Click;
        private EventHandler gestionarUsuarioToolStripMenuItem_Click;
        private EventHandler nuevoPedidosToolStripMenuItem_Click;
    }
}
