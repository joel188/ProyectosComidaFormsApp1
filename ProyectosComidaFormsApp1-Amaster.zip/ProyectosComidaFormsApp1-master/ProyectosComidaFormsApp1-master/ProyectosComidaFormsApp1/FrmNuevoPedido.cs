﻿using System;

namespace ProyectosComidaFormsApp1
{
    internal class FrmNuevoPedido
    {
        public FrmCuenta MdiParent { get; internal set; }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}