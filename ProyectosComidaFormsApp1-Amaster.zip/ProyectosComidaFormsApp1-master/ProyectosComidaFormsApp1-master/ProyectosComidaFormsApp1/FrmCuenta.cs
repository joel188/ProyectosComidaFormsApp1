﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace ProyectosComidaFormsApp1
{
    public partial class FrmCuenta : Form
    {
        private List<CuentaNueva> cuentas;
        private Usuario currentUser;

        public bool IsConfirmed { get; internal set; }
        public string CuentNomEmptxt { get; internal set; }
        public string CuentNumEmptxt { get; internal set; }
        public string CuentNombClientxt { get; internal set; }
        public string CuentNumClientxt { get; internal set; }
        public string CuentComboMenu { get; internal set; }
        public string CuentUbicaciontxt1 { get; internal set; }
        public string CuentComboCalificacion { get; internal set; }

        public FrmCuenta(Usuario usuario)
        {
            InitializeComponent();
            cuentas = new List<CuentaNueva>();
            currentUser = usuario;
        }

        public FrmCuenta()
        {
        }

        private void FrmCuenta_Load(object sender, EventArgs e)
        {
            ConfigurarMenu();
            CargarCuentas();
            MessageBox.Show($"Bienvenido, {currentUser.Nombre}", "Bienvenida", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ConfigurarMenu()
        {
            if (currentUser.Rol == "Admin")
            {
                pedidosToolStripMenuItem.Visible = true;
                usuarioToolStripMenuItem.Visible = true;
            }
            else if (currentUser.Rol == "Usuario")
            {
                pedidosToolStripMenuItem.Visible = true;
                usuarioToolStripMenuItem.Visible = false;
            }
        }

        private void CargarCuentas()
        {
            cuentas.Add(new CuentaNueva { Id = 1, Nombre = "Cuenta 1", Saldo = 1000 });  
            cuentas.Add(new CuentaNueva { Id = 2, Nombre = "Cuenta 2", Saldo = 800 });  
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void NuevoPedidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevoPedido frmNuevoPedido = new FrmNuevoPedido();
            frmNuevoPedido.MdiParent = this;
            frmNuevoPedido.Show();
        }

        private void GestionarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmGestionarUsuarios frmGestionarUsuarios = new FrmGestionarUsuarios();
            frmGestionarUsuarios.MdiParent = this;
            frmGestionarUsuarios.Show();
        }
    }

    // Definición única de la clase Cuenta
    public class CuentaNueva
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public decimal Saldo { get; set; }
    }

    public class Usuario
    {
        public string Nombre { get; set; }
        public string Rol { get; set; }
    }
}
